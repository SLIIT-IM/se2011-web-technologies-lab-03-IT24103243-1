
let welcomeBtn = document.getElementById("welcomeBtn");
let welcomeMessage = document.getElementById("welcomeMessage");

welcomeBtn.onclick = function () {
    welcomeMessage.textContent = "Welcome to Campus Tech Store!";
};


let productTable = document.getElementById("productTable");
let productCount = document.getElementById("productCount");

productCount.textContent = productTable.rows.length - 1;

let discountBtn = document.getElementById("discountBtn");

discountBtn.onclick = function () {
    let price = Number(document.getElementById("priceInput").value);

    if (price > 0) {
        let discount = price * 0.1;
        let final = price - discount;

        document.getElementById("discountResult").textContent =
            "Final Price: " + final;
    }
};


document.getElementById("offersBtn").onclick = function () {
    document.getElementById("offersMessage").textContent =
        "Special student offer available!";
};


let products = ["Laptop", "Headphones", "Smart Watch", "USB Flash Drive"];

document.getElementById("searchBtn").onclick = function () {
    let input = document.getElementById("searchInput").value.toLowerCase();
    let found = false;

    for (let i = 0; i < products.length; i++) {
        if (products[i].toLowerCase() === input) {
            found = true;
        }
    }

    document.getElementById("searchResult").textContent =
        found ? "Found!" : "Not found";
};


document.getElementById("showProductsBtn").onclick = function () {
    let list = document.getElementById("productListDisplay");
    list.innerHTML = "";

    for (let i = 0; i < products.length; i++) {
        list.innerHTML += "<li>" + products[i] + "</li>";
    }
};


document.getElementById("contactForm").onsubmit = function (e) {
    e.preventDefault();

    let email = document.getElementById("email").value;
    let message = document.getElementById("message").value;

    if (!email.includes("@")) {
        formMessage.textContent = "Invalid email";
    } else if (message.length < 10) {
        formMessage.textContent = "Message too short";
    } else {
        formMessage.textContent = "Success!";
    }
};


document.getElementById("themeBtn").onclick = function () {
    document.body.classList.toggle("dark-mode");
};


function updateClock() {
    let now = new Date();
    document.getElementById("clock").textContent =
        now.toLocaleTimeString();
}

setInterval(updateClock, 1000);